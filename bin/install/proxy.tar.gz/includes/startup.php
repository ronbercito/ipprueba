<?php
if (posix_getpwuid(posix_geteuid())['name'] <> "root") { exit("Please run as root!\n"); }
$rCronjob = "* * * * * /home/xui/bin/php/bin/php /home/xui/crons/callback.php # XUI Proxy\n";
$rTempName = tempnam("/tmp", "crontab");
file_put_contents($rTempName, $rCronjob);
shell_exec("sudo crontab -r");
shell_exec("sudo crontab -u root \"".$rTempName."\"");
@unlink($rTempName);
?>
